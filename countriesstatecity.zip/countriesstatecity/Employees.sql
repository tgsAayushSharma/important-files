USE [Employee]
GO

/****** Object:  Table [dbo].[Employee]    Script Date: 17-01-2024 13:12:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Employee](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[Email] [varchar](50) NULL,
	[Gender] [varchar](1) NULL,
	[Marital Status] [bit] NULL,
	[BirthDate] [date] NULL,
	[Hobbies] [varchar](100) NULL,
	[Salary] [decimal](10, 2) NULL,
	[Address] [varchar](500) NULL,
	[CountryId] [int] NULL,
	[StateId] [int] NULL,
	[CityId] [int] NULL,
	[ZipCode] [varchar](6) NULL,
	[Password] [varchar](50) NULL,
	[Created] [datetime] NULL,
	[Photo] [varchar](255) NULL,
 CONSTRAINT [PK_Employee] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Employee]  WITH CHECK ADD  CONSTRAINT [FK_Employee_Cities] FOREIGN KEY([CityId])
REFERENCES [dbo].[Cities] ([id])
GO

ALTER TABLE [dbo].[Employee] CHECK CONSTRAINT [FK_Employee_Cities]
GO

ALTER TABLE [dbo].[Employee]  WITH CHECK ADD  CONSTRAINT [FK_Employee_Countries] FOREIGN KEY([CountryId])
REFERENCES [dbo].[Countries] ([id])
GO

ALTER TABLE [dbo].[Employee] CHECK CONSTRAINT [FK_Employee_Countries]
GO

ALTER TABLE [dbo].[Employee]  WITH CHECK ADD  CONSTRAINT [FK_Employee_States] FOREIGN KEY([StateId])
REFERENCES [dbo].[States] ([id])
GO

ALTER TABLE [dbo].[Employee] CHECK CONSTRAINT [FK_Employee_States]
GO


